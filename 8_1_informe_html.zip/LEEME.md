# 8.1. Informe HTML

Fuente versionada: 99bb25def5d760ab2fe0e719c1d79c59804b8935.

Abrir informe/intro.html después de descomprimir. Alternativa: `python -m http.server 8000 --directory informe`. MathJax y los enlaces externos pueden necesitar Internet. ARTEFACTOS_EXTERNOS.json identifica las descargas individuales históricas no incluidas.

Se conserva el alcance científico del libro: respaldo aplicado parcial de MLP/CNN1D; suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
