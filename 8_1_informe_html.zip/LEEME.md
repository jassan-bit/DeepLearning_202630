# 8.1. Informe HTML

Fuente versionada: 67a082e57bafdcd60dde0aa70843449c473a8c56.

Abrir informe/intro.html después de descomprimir. Alternativa: `python -m http.server 8000 --directory informe`. MathJax y los enlaces externos pueden necesitar Internet. ARTEFACTOS_EXTERNOS.json identifica las descargas individuales históricas no incluidas.

Se conserva el alcance científico del libro: seis textos del corpus BTC y39 referencias. Miura2019 respalda MLP/CNN independientes como familias. Bucci2020 aporta un original de revista con FNN financiera; HARNet aporta código autor Conv1D; DeepVol tiene identidad editorial en CV, con original pendiente. Estas fuentes metodológicas no añaden estudios BTC ni revelan la dimensionalidad no reportada de la CNN de Miura. No son réplicas de las recetas. suplemento final post-hoc y nuevo piloto registrado de60 trayectorias; el R definitivo aún no se ejecutó. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
