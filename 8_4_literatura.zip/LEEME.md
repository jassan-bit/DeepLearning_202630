# 8.4. Síntesis de literatura y flujo

Fuente versionada: aaeee5d8568b4828301148efe86712585fbe93e4.

La síntesis vigente de seis estudios, frecuencias y Tabla1 de Miura2019 están en book/_static/literature_e1/recovery_20261105/. La bibliografía principal reúne36referencias. Los archivos anteriores conservan sus cortes históricos; no sumar etapas sin deduplicación. No se incluyen manuscritos de terceros.

Se conserva el alcance científico del libro: Miura2019 respalda MLP/CNN independientes como familias; no declara dimensionalidad CNN ni demuestra una réplica exacta o uso amplio. suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
