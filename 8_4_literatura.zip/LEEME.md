# 8.4. Síntesis de literatura y flujo

Fuente versionada: 67a082e57bafdcd60dde0aa70843449c473a8c56.

La síntesis BTC de seis estudios, frecuencias y Tabla1 de Miura2019 están en book/_static/literature_e1/recovery_20261105/. El catálogo vigente de39 referencias y la ampliación metodológica T1/T2/T3 están en journal_update_20261105/: artículo Bucci leído, código HARNet verificado e identidad DeepVol con original pendiente. La indexación de revistas es secundaria; no se acreditan registros individuales o Q1. No sumar fuentes metodológicas al denominador BTC. No se incluyen manuscritos de terceros.

Se conserva el alcance científico del libro: seis textos del corpus BTC y39 referencias. Miura2019 respalda MLP/CNN independientes como familias. Bucci2020 aporta un original de revista con FNN financiera; HARNet aporta código autor Conv1D; DeepVol tiene identidad editorial en CV, con original pendiente. Estas fuentes metodológicas no añaden estudios BTC ni revelan la dimensionalidad no reportada de la CNN de Miura. No son réplicas de las recetas. suplemento final post-hoc y nuevo piloto registrado de60 trayectorias; el R definitivo aún no se ejecutó. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
