# Seguimiento de E2 — 16/11/2026

Extraiga toda la carpeta y ejecute: python run.py (Python 3.10 o posterior).
Abra output/informe.html. Usa biblioteca estándar, sin red, Git, Torch ni otros
paquetes. Verifica los archivos, repite la deducción algebraica de RQ3 y genera
un diagnóstico de disponibilidad. Conserve o renombre output/ antes de repetir.

Funciona por separado para esas tareas. No incluye los doce ZIP v2 ni los OHLCV
ausentes; no entrena modelos ni ejecuta controles de fuga. Los bloqueos se muestran
aunque la verificación del suplemento sea correcta.

Para orquestar los análisis de los doce entregables, descargue los ZIP v2 del
inventario reproduction_inputs.json incluido y ejecute:

    python scripts/reproduce_e2_campaign.py --replay --archives-dir RUTA_ZIPS --output SALIDA_NUEVA

Los entornos se indican con --python, --model-python, --analysis-python y
--book-python. Consulte --help y el README de reproducción incluido para sus
versiones. No se instalan dependencias automáticamente. La salida 2 del
orquestador significa parcial; 1 indica error. La reproducción analítica no
repite toda la selección, entrenamientos, ablaciones e inferencias de mercado.

Los tiempos de fases y cargos de campaña tienen ámbitos solapados y no se suman.
NAS no aplica. La IUT original sigue sin ejecutarse.
