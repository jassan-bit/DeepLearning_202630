"""Verify this supplement and reproduce its algebraic deduction."""
from pathlib import Path
import hashlib, html, json, subprocess, sys
ROOT=Path(__file__).resolve().parent
def main():
    manifest=json.loads((ROOT/"source_manifest.json").read_text(encoding="utf-8"))
    for row in manifest["files"]:
        relative=Path(row["path"])
        if relative.is_absolute() or ".." in relative.parts: raise ValueError("Unsafe manifest path")
        path=ROOT/relative
        if path.is_symlink() or not path.is_file() or path.stat().st_size!=row["bytes"] or hashlib.sha256(path.read_bytes()).hexdigest()!=row["sha256"]:
            raise ValueError("Changed or missing input: "+str(relative))
    output=ROOT/"output"
    if output.exists(): raise ValueError("Preserve previous output; rename its folder before repeating")
    output.mkdir()
    subprocess.run([sys.executable,str(ROOT/"scripts/e2_rq3_necessary_component.py"),"--output",str(output/"RQ3")],check=True)
    process=subprocess.run([sys.executable,str(ROOT/"scripts/reproduce_e2_campaign.py"),"--check","--output",str(output/"readiness")],check=False)
    if process.returncode not in (0,2): raise RuntimeError("Readiness validation failed")
    status=json.loads((output/"readiness/reproduction_status.json").read_text())
    proof=json.loads((output/"RQ3/necessary_component_proof.json").read_text())
    report={"source_commit":manifest["source_commit"],"included_files_verified":len(manifest["files"]),
            "RQ3_all_cost_bounds_equal_one":proof["all_ten_lower_bounds_equal_one"],
            "full_CPU_IUT_executed":False,"full_campaign_passed":False,
            "readiness_status":status["status"],"new_training_or_inference":False,
            "network_downloads":False,"readiness_exit_code":process.returncode}
    (output/"execution_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    body="<html lang='es'><meta charset='utf-8'><title>Seguimiento E2</title><h1>Seguimiento E2</h1><p>Archivos verificados y deducción de RQ3 reproducida. No se establece mejora conjunta en el CPU medido.</p><p>La auditoría integral, los controles reales y toda la campaña de entrenamiento conservan sus bloqueos. La salida parcial es deliberada.</p><pre>"+html.escape(json.dumps(report,ensure_ascii=False,indent=2))+"</pre></html>"
    (output/"informe.html").write_text(body,encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False))
    return 0
if __name__=="__main__": raise SystemExit(main())
