@echo off
py -3 run.py
pause
