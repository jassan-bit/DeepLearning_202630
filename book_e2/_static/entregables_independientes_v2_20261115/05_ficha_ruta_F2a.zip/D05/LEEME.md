# D05 · Ficha metodológica F2a y evidencia estadística

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Valida los esquemas de las entradas incluidas y genera un informe HTML navegable, tablas/JSON y exportaciones originales. No necesita el sitio ni otros paquetes de entrega.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Las verificaciones son de integridad y coherencia semántica del documento/registro, con datos reales incluidos. No sustituyen controles experimentales pendientes ni repiten entrenamientos. Los estados parciales quedan visibles.

## Correcciones posteriores incluidas

Las carpetas corrections/ conservan el espacio de nombres de cada área: planes, recibos, tablas, fuentes y estados. Los informes predeterminados verifican esas entradas y muestran sus resultados; no vuelven a ajustar redes, ejecutar controles o remuestrear. Los resultados adversos, no estimables o pendientes se conservan. Estas ampliaciones no sustituyen A2 ni acreditan una defensa oral.

## Repetir los suplementos estadísticos incluidos

Instala requirements_corrections.txt en un entorno separado y ejecuta `python reanalysis/run.py --output nueva_repeticion`. Se incluyen los programas originales exactos, planes fechados y todos sus insumos en sus rutas relativas. El adaptador llama a execute, sin Git, tokens, descarga, nuevo registro o ajustes de modelos. Compara las tablas numéricas con las referencias incluidas. reanalysis/config.json enumera los programas realmente disponibles. La repetición de efectos/RQ2 y el diagnóstico complementario CPU, si está incluido, conservan sus propios alcances. El suplemento CPU no acredita paridad CUDA, ausencia de sobreajuste original ni la IUT/RQ3 original; los dos fallos de paridad permanecen visibles. No se promete reproducir toda la campaña.

## Procedencia

Fuente documental: `ad8f163c1bbed55348c4af3d3c71b71f57bc7c55`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
