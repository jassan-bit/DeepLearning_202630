# D12 · Presentación de defensa y notas del orador

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Genera 14 diapositivas HTML autónomas, notas y el benchmark reconstruido. Abre output/presentacion.html, usa flechas y Ctrl+P para imprimir/guardar PDF.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Las diapositivas y notas están preparadas para la defensa; su generación no acredita que la presentación oral ya haya ocurrido. No necesitan PowerPoint, CDN ni el sitio del curso. El contenido mantiene los resultados negativos, unidades y límites del estudio.

## Procedencia

Fuente documental: `204a8543234aac1614e0b76914bd914e28567eb9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
