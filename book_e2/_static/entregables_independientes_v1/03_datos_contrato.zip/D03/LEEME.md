# D03 · Datos, Data Card y contrato

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Reconstruye las 716 etiquetas de desarrollo desde los cierres incluidos, verifica calidad/cohortes y produce un informe y CSV.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Incluye los dos CSV diarios de desarrollo, la Data Card, contrato y manifiestos. CSV diario y tensor de ventanas no son el mismo objeto. No incluye ni inventa los tensores finales X/escalares de test. Descarga opcional: `python run.py --download --archive BTCUSDT-1m-2023-01.zip`; requiere Internet y verifica CHECKSUM/hash oficiales. Sin --archive, la descarga selecciona los 24 meses de desarrollo; no se inicia por defecto.

## Procedencia

Fuente documental: `204a8543234aac1614e0b76914bd914e28567eb9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
