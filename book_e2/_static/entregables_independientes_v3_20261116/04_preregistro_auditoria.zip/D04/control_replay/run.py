"""Reconstruct recorded control arithmetic without fitting or resampling.

AUC uses the exact included original kernel. The empirical permutation p uses
the 999 already fitted null AUCs; no classifier is refitted. Negative-control gain
and Spearman use their saved 608 predictions. Published CIs/Holm results are copied.
"""
from pathlib import Path
import argparse,csv,hashlib,importlib.util,json,math
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def checked(name):
    p=(ROOT/name).resolve()
    if not p.is_relative_to(ROOT.resolve()) or not p.is_file() or p.is_symlink():raise ValueError("Unsafe control replay path")
    return p
def same(a,b):
    if a is None or b is None:return a is None and b is None
    return math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12)
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--output",type=Path,required=True);args=parser.parse_args()
    if args.output.exists():raise ValueError("Use a new control replay output directory")
    config=json.loads((BASE/"config.json").read_text())
    for record in config["bound_files"]:
        p=checked(record["path"])
        if p.stat().st_size!=record["bytes"] or digest(p)!=record["sha256"]:raise ValueError("Control replay input changed: "+record["path"])
    import numpy as np
    from scipy.stats import rankdata
    spec=importlib.util.spec_from_file_location("_e2_saved_control_kernel",checked(config["kernel"]))
    kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
    if sum(r["kind"]=="adversarial" for r in config["predictions"])!=1 or {r["model"] for r in config["predictions"] if r["kind"]=="negative"}!=set(kernel.MODELS):raise ValueError("Control predictor identities are incomplete")
    with np.load(checked(config["cohorts"]),allow_pickle=False) as data:
        truth=data[config["test_y_key"]].copy();dates=data[config["test_dates_key"]].copy();scale=float(data[config["target_scale_key"]].item())
    if truth.shape!=(608,) or not np.isfinite(truth).all():raise ValueError("Incomplete actual evaluation targets")
    summary=json.loads(checked(config["negative_summary"]).read_text());negatives={r["model"]:r for r in summary["rows"]}
    rows=[];preserved=[]
    for entry in config["predictions"]:
        receipt=json.loads(checked(entry["receipt"]).read_text())
        with np.load(checked(entry["path"]),allow_pickle=False) as data:
            if entry["kind"]=="adversarial":
                labels=data["labels"];predictions=data["predictions"];null=data["permutation_AUC"]
                if labels.shape!=(1263,) or predictions.shape!=(1263,) or null.shape!=(999,) or not np.isfinite(null).all():raise ValueError("Incomplete saved adversarial design")
                observed=kernel.auc(labels,predictions);p=float((1+np.sum(null>=observed))/(1+len(null)))
                if not same(observed,receipt["AUC_OOF"]) or not same(p,receipt["p_block_permutation_with_refit"]):raise ValueError("Saved adversarial arithmetic differs")
                rows.extend([{"control":"adversarial","metric":"AUC_OOF","observed":observed,"reference":receipt["AUC_OOF"]},
                             {"control":"adversarial","metric":"p_from_saved999nullAUCs","observed":p,"reference":receipt["p_block_permutation_with_refit"]}])
                preserved.append({"control":"adversarial","published_CI":receipt.get("fixed_OOF_temporal_CI"),"CI_recomputed":False})
            else:
                prediction=data["prediction"];stored_truth=data["truth"]
                if prediction.shape!=(608,) or not np.isfinite(prediction).all() or not np.array_equal(data["dates"],dates) or not np.array_equal(stored_truth,truth):raise ValueError("Saved negative-control cohort changed")
                gain=math.sqrt(float(((scale-truth)**2).mean()))-math.sqrt(float(((prediction-truth)**2).mean()))
                a,b=rankdata(prediction),rankdata(truth)
                rho=float(np.corrcoef(a,b)[0,1]) if np.std(a) and np.std(b) else None
                reference=negatives[entry["model"]]
                if not same(gain,reference["gain_RMSE_vs_training_mean"]) or not same(rho,reference["Spearman_rho"]):raise ValueError("Saved negative-control arithmetic differs: "+entry["model"])
                rows.extend([{"control":entry["model"],"metric":"gain_RMSE_vs_training_mean","observed":gain,"reference":reference["gain_RMSE_vs_training_mean"]},
                             {"control":entry["model"],"metric":"Spearman_rho","observed":rho,"reference":reference["Spearman_rho"]}])
                preserved.append({"control":entry["model"],"published_gain_CI95":reference["gain_CI95"],"published_rho_CI95":reference["rho_CI95"],"published_p_Holm13":reference["p_Holm13"],"published_flag":reference["flag"],"CI_or_Holm_recomputed":False})
    if len(rows)!=28 or len(preserved)!=14:raise ValueError("Incomplete original 13 negative + 1 adversarial control set")
    args.output.mkdir(parents=True)
    with (args.output/"control_arithmetic.csv").open("w",encoding="utf-8",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=["control","metric","observed","reference"],lineterminator="\n");writer.writeheader();writer.writerows(rows)
    report={"status":"verified","scope":"Numerical reproduction from included saved control outputs; classifier folds/null fits and original CIs remain represented by their immutable receipts", "source_commit":config["source_commit"],"arithmetic_checks":len(rows),"published_results_preserved":preserved,"new_model_fits":0,"new_model_inference":False,"new_resampling":0,"new_hypothesis_test":False}
    (args.output/"control_replay_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
