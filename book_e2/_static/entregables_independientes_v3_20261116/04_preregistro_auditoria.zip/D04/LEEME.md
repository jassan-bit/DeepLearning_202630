# D04 · Preregistro y auditoría de datos

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Valida los esquemas de las entradas incluidas y genera un informe HTML navegable, tablas/JSON y exportaciones originales. No necesita el sitio ni otros paquetes de entrega.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Las verificaciones son de integridad y coherencia semántica del documento/registro, con datos reales incluidos. No sustituyen controles experimentales pendientes ni repiten entrenamientos. Los estados parciales quedan visibles.

## Correcciones posteriores incluidas

corrections/ conserva las evidencias del 15 de noviembre y scientific_closure/ las ampliaciones del 16 de noviembre pertinentes a este entregable. package.json enumera áreas y archivos realmente disponibles; incluirlos no convierte una ausencia, alerta o fallo en éxito. Los informes predeterminados verifican esas entradas y muestran sus resultados; no vuelven a ajustar redes, ejecutar controles o remuestrear. Estas ampliaciones no sustituyen A2, no crean un test ciego nuevo y no acreditan una defensa oral.

## Reauditar los datos incluidos

`python audit_data/run.py --output output/data_reaudit` ejecuta el verificador con Python estándar, sin Git ni otros ZIP. Si current_dataset_bundle.json está incluido, comprueba también el CSV original de evaluación 608 y el NPZ real de 655/53/608. Reconstruye σ7 y comprueba calendarios, soporte e integridad de los arrays. No verifica por sí solo los trece ports o los 81 checkpoints; sus recibos y límites se conservan por separado.

## Reconstruir la aritmética de los controles

Instala requirements_controls_replay.txt y ejecuta `python control_replay/run.py --output nuevos_controles_replay`. Usa las 14 copias NPZ verificadas: AUC y p empírico desde los 999 valores nulos ya guardados, más gain y Spearman de los 13 controles negativos. No vuelve a ajustar clasificadores o redes, no remuestrea y no recalcula sus IC o Holm13; conserva esos resultados publicados. El modo predeterminado del entregable sigue usando sólo Python estándar.

## Procedencia

Fuente documental: `78271c46a1fe7a9544e8d1ec46e096dafb7cf9e9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
