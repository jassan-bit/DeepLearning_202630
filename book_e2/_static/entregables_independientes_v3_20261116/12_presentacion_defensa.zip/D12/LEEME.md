# D12 · Presentación de defensa y notas del orador

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Genera diapositivas HTML autónomas, notas y el benchmark reconstruido, con los suplementos actuales incluidos. Abre output/presentacion.html, usa flechas y Ctrl+P para imprimir/guardar PDF.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Las diapositivas y notas están preparadas para la defensa; su generación no acredita que la presentación oral ya haya ocurrido. No necesitan PowerPoint, CDN ni el sitio del curso. El contenido mantiene los resultados negativos, unidades y límites del estudio.

## Correcciones posteriores incluidas

corrections/ conserva las evidencias del 15 de noviembre y scientific_closure/ las ampliaciones del 16 de noviembre pertinentes a este entregable. package.json enumera áreas y archivos realmente disponibles; incluirlos no convierte una ausencia, alerta o fallo en éxito. Los informes predeterminados verifican esas entradas y muestran sus resultados; no vuelven a ajustar redes, ejecutar controles o remuestrear. Estas ampliaciones no sustituyen A2, no crean un test ciego nuevo y no acreditan una defensa oral.

## Repetir los suplementos estadísticos incluidos

Instala requirements_corrections.txt en un entorno separado y ejecuta `python reanalysis/run.py --output nueva_repeticion`. Se incluyen los programas originales exactos, planes fechados y todos sus insumos en sus rutas relativas. El adaptador llama a execute, sin Git, tokens, descarga, nuevo registro o ajustes de modelos. Compara las tablas numéricas con las referencias incluidas. reanalysis/config.json enumera los programas realmente disponibles. La repetición de efectos/RQ2 y el diagnóstico complementario CPU, si está incluido, conservan sus propios alcances. El suplemento CPU no acredita paridad CUDA, ausencia de sobreajuste original ni la IUT/RQ3 original; los dos fallos de paridad permanecen visibles. No se promete reproducir toda la campaña.

## Repetir los análisis actuales

En otro entorno instala requirements_scientific.txt. scientific_reanalysis/config.json enumera los programas realmente incluidos. Ejecuta `python scientific_reanalysis/run.py --program period_comparison --output nueva_comparacion_periodos` o `python scientific_reanalysis/run.py --program cpu_test_iut --output nueva_IUT_CPU`, si aparecen en esa lista. Conserva los programas y planes exactos; adapta únicamente la ubicación de fuentes absolutas a copias incluidas verificadas. Compara las tablas contra sus referencias. Esta repetición puede remuestrear según el plan ya ejecutado: no ajusta modelos, no realiza inferencia ni registra una hipótesis nueva, y no convierte la IUT CPU secundaria en la IUT A100 original.

## Repetir el análisis de metadatos HPO

Instala requirements_hpo_reanalysis.txt y ejecuta `python hpo_reanalysis/run.py --output nueva_revision_hpo`. El adaptador copia el plan y sources incluidos a una salida nueva y llama al execute original byte por byte, sin Git, red, recuperación de datos o nuevos ajustes. Verifica las tablas frente a sus referencias. No uses --recover-only ni --register-plan para este replay: conservar el registro previo es parte del alcance.

## Procedencia

Fuente documental: `78271c46a1fe7a9544e8d1ec46e096dafb7cf9e9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
