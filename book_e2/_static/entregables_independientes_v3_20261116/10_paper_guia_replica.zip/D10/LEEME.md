# D10 · Paper guía y réplica parcial

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Recalcula media, DE, IC y discrepancias de las cinco semillas ETTh1; reconstruye curvas/figuras e informe. No entrena por defecto.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Incluye ETTh1 original sin modificar, su licencia/atribución, 23 fuentes de autores verificadas y el driver original. Default no necesita NumPy/Torch; los NPZ históricos privados no se sustituyen por agregados. `python run.py --validate-training` comprueba todo sin entrenar. Para una repetición nueva CPU: instala requirements_training.txt y ejecuta `python run.py --train --seed 2019 --output nueva_replica`; sin --seed entrena las cinco semillas y puntúa. Puede tardar horas. El registro local nuevo se distingue del preregistro histórico. Esa repetición no se ejecutó al preparar este paquete.

## Procedencia

Fuente documental: `78271c46a1fe7a9544e8d1ec46e096dafb7cf9e9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
