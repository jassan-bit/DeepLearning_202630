# 8.5. Benchmark e inferencia agregada

Fuente versionada: 99bb25def5d760ab2fe0e719c1d79c59804b8935.

Abrir los CSV con un lector compatible con UTF-8. analysis_cv/ contiene desarrollo; test/analysis/ contiene test. Los suplementos inference/ y descriptive/ conservan su registro post-hoc. Los manifiestos de listas permitidas verifican los agregados originales.

Se conserva el alcance científico del libro: respaldo aplicado parcial de MLP/CNN1D; suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
