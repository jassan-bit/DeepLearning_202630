# 8.2. Código EDA, modelos y análisis

Fuente versionada: 99bb25def5d760ab2fe0e719c1d79c59804b8935.

El código conserva scripts/ y tests/. Leer BUILD.md: entornos separados, adquisición, preparación, entrenamiento y análisis. Para recalcular la ejecución original se necesita la evidencia privada; no ejecutar los originales sobre un registro firmado ni borrar sus marcadores.

Se conserva el alcance científico del libro: respaldo aplicado parcial de MLP/CNN1D; suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
