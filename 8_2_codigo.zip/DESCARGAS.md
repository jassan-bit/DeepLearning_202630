# Descargas del Entregable 1

[Descargar directamente desde la unidad 8 del Jupyter Book](https://jassan-bit.github.io/DeepLearning_202630/sections/08_entregables.html#descargar-entregable-1).

[Descargar los siete entregables juntos (ZIP)](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/entregable1_completo.zip) · [Ver carpeta de descargas](https://github.com/jassan-bit/DeepLearning_202630/tree/entregables)

Estos archivos se descargan directamente desde GitHub y se utilizan fuera del Jupyter Book.

| Ítem | Archivo | Contenido |
|---|---|---|
| 8.1 | [Informe HTML](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_1_informe_html.zip) | Informe navegable, figuras y archivos públicos de respaldo |
| 8.2 | [Código](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_2_codigo.zip) | Scripts EDA, MLP/LSTM/CNN1D, análisis estadístico, pruebas, dependencias y `BUILD.md` |
| 8.3 | [Obtención del dataset](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_3_dataset_instrucciones.zip) | Instrucciones exactas, descargador de Binance y manifiestos de adquisición |
| 8.4 | [Literatura y flujo](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_4_literatura.zip) | Tabla de síntesis, extracción, evaluación de calidad y diagrama de búsqueda |
| 8.5 | [Benchmark e inferencia](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_5_benchmark.zip) | Métricas agregadas de CV/test y suplemento estadístico con sus límites |
| 8.6 | [Configuraciones](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_6_configuraciones.zip) | Dependencias, semillas y catálogos de 1.440 segmentos CV y 120 ajustes finales |
| 8.7 | [Declaración](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/8_7_declaracion.zip) | Métrica, margen, unidad de independencia, partición y cronología de decisiones |

Descomprime el archivo antes de abrirlo y consulta su `LEEME.md`. En el informe, abre `informe/intro.html`. Si el navegador restringe los recursos locales, desde la carpeta extraída ejecuta:

```bash
python -m http.server 8000 --directory informe
```

Después abre <http://localhost:8000>. Las fórmulas MathJax y las fuentes enlazadas pueden necesitar internet.

El código incluye los ejecutores y el manual para preparar sus entornos. La verificación de resultados individuales originales requiere el paquete privado de evidencia descrito en `BUILD.md`. El paquete público de datos entrega la ruta exacta y el descargador para obtener los ZIP brutos de Binance; esos ZIP no forman parte del paquete privado. Las predicciones individuales y los pesos se conservan en la entrega privada. Las tablas y figuras públicas no sustituyen esos insumos.

La [versión y el inventario de los paquetes](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/catalogo.json) quedan registrados en `catalogo.json`. Para comprobar las descargas, guarda [SHA256SUMS.txt](https://raw.githubusercontent.com/jassan-bit/DeepLearning_202630/entregables/SHA256SUMS.txt) junto a los ZIP y ejecuta:

```bash
sha256sum --ignore-missing -c SHA256SUMS.txt
```

La síntesis de **seis textos BTC** y la extracción de Miura, Pichl y Kaizoji (2019) se conservan en `book/_static/literature_e1/recovery_20261105/`. El corte histórico de **39 referencias** y sus fichas están en `book/_static/literature_e1/journal_update_20261105/` dentro del ZIP de literatura. La ampliación distingue un original de revista leído de Bucci, código primario de autor de HARNet y una identidad editorial de DeepVol corroborada mediante un CV; no son tres nuevos textos BTC ni tres manuscritos completos leídos. El original respalda una FNN pequeña en otro mercado y el código explicita Conv1D causal; las recetas propias siguen siendo adaptaciones. Se entregan fichas y tablas, sin redistribuir esos artículos completos de terceros. La revisión posterior al benchmark no modifica sus resultados ni entrena modelos. El criterio académico avanzado conserva su definición posterior al test y su alcance futuro.

El paquete de benchmark incluye también `e1_filipe_pilot_20261105/`:60 trayectorias piloto nuevas, con registro anterior a sus ajustes sobre el calendario2024 ya conocido. Informa dispersión, dimensionamiento y MDE; no afirma potencia alcanzada ni sustituye una evaluación temporal independiente. Los catálogos distinguen las720 configuraciones mensuales nuevas de las originales.

Los ZIP 8.5/8.6/8.7 añaden `e1_filipe_confirmatory_d7_20261105/`: ampliación de 20 semillas por modelo y fase definitiva de 79 semillas nuevas por modelo, con protocolo y R publicados antes de cada etapa. Incluyen agregados, configuraciones públicas, contraste de tres pares y auditorías de las dos fases. El código de ejecución y verificación está en 8.2. El estudio se limita a la aleatoriedad del entrenamiento sobre 2024 conocido; los pesos, escaladores y predicciones individuales permanecen privados.

La versión vigente del ZIP 8.4 incorpora `literature_e1/crypto_extension_20261105/`: **40 referencias, siete textos cripto y una matriz de diez registros**. Incluye S9 sobre 20 activos, frecuencias con denominadores y roles explícitos, cribado, flujo y la errata de HARNet. El ZIP 8.7 conserva la declaración de esta ampliación posterior al benchmark. La presencia de otras criptomonedas en la literatura no añade datos o entrenamientos al experimento de Bitcoin.
