from pathlib import Path
import hashlib,json,runpy,sys
ROOT=Path(__file__).resolve().parent
for name, expected in json.loads((ROOT/'manifest.json').read_text()).items():
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
        raise ValueError('Contenido modificado: '+name)
if '--output' not in sys.argv:
    sys.argv.extend(['--output',str(ROOT/'output')])
runpy.run_path(str(ROOT/'replay_inference.py'),run_name='__main__')
if '--point-only' not in sys.argv:
    output=Path(sys.argv[sys.argv.index('--output')+1])
    for name in ['conditional_OOF_test_comparisons_39.csv','finite_loss_variance_components_15.csv']:
        if (output/name).read_bytes()!=(ROOT/'reference'/name).read_bytes():
            raise ValueError('La tabla difiere de la referencia: '+name)
    print('Dos tablas reconstruidas; discrepancia cero con las referencias.')
