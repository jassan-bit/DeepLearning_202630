# Reanálisis inferencial independiente

Requiere Python 3.11+ y NumPy 2.3.5. Extraiga toda la carpeta.

```bash
python -m pip install -r requirements.txt
python run.py
```

El comando reconstruye las dos tablas de `reference/`, con 5.000 remuestreos por bloque (14,7,28 días), y compara sus bytes. Guarda resultados en `output/`; utilice una carpeta nueva para repetir: `python run.py --output otra_salida`. `--point-only` genera sólo estimaciones puntuales. No usa Git, red, pesos, Torch ni ajusta modelos. Tarda aproximadamente 25 segundos en el CPU verificado; depende del equipo.

Compara 249 fechas OOF de ganadores históricos con 608 fechas de prueba de entrenamientos distintos; selección condicionada, sin validación externa nueva. Descompone pérdidas de este catálogo finito, sin inferir varianza entre mercados o nuevas particiones. No rechazo no demuestra equivalencia. La A2 original no se modifica.
