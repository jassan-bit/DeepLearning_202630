# D06 · Benchmark, métricas y comparaciones

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Recalcula RMSE, MAE, sMAPE, R², cobertura y anchura de los 81 predictores desde sus pronósticos guardados; comprueba A2 y genera tabla, gráfico e informe.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Default: biblioteca estándar, sin red, GPU o pesos. Los IC t y p se conservan como valores publicados y no se recalculan silenciosamente. Para repetir bootstrap/t/sign-flip originales: instala requirements_analysis.txt y ejecuta `python run.py --full-primary --draws 4999 --output reanalisis_original`. La opción recalcula pruebas con el programa original; puede tardar y no entrena modelos. Para el refinamiento usa --draws 20000.

## Procedencia

Fuente documental: `204a8543234aac1614e0b76914bd914e28567eb9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
