# D11 · Lista de reproducibilidad y evidencia

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Valida los esquemas de las entradas incluidas y genera un informe HTML navegable, tablas/JSON y exportaciones originales. No necesita el sitio ni otros paquetes de entrega.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Los 21 ítems conservan sus estados: 9 completos dentro de su alcance, 10 parciales y 2 NAS no aplicables. El runner valida coherencia y exporta las evidencias; no declara todos los criterios aprobados ni reentrena los 81 modelos.

## Procedencia

Fuente documental: `204a8543234aac1614e0b76914bd914e28567eb9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
