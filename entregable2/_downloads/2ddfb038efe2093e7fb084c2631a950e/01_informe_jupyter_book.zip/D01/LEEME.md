# D01 · Informe Jupyter Book completo y fuentes

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Extrae y valida el libro completo y sus fuentes en output/. Abre output/site/intro.html; para navegación servida, python run.py --serve.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

El snapshot científico/documental corresponde al commit 204a8543234aac1614e0b76914bd914e28567eb9. Incluye 70 páginas HTML y fuentes completas del libro, con MathJax local y licencias. Necesita aproximadamente 400 MB libres al extraer. `--serve --port 8765` inicia un servidor sólo en 127.0.0.1; Ctrl+C lo detiene. Para reconstruir el libro: instala `output/source/requirements-book.lock.txt` y ejecuta `python run.py --build`. El build recompila el informe, no repite entrenamientos.

## Procedencia

Fuente documental: `204a8543234aac1614e0b76914bd914e28567eb9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
