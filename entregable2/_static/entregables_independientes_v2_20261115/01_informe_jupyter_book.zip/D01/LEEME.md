# D01 · Informe Jupyter Book completo y fuentes

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Extrae y valida el libro completo y sus fuentes en output/. Abre output/site/intro.html; para navegación servida, python run.py --serve.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

El snapshot científico/documental corresponde al commit ad8f163c1bbed55348c4af3d3c71b71f57bc7c55. Incluye 71 páginas HTML y la proyección de fuentes del libro, con MathJax local y licencias. El manifiesto inventaría 472494552 bytes antes de extraer; una reconstrucción necesita espacio adicional para su salida. `--serve --port 8765` inicia un servidor sólo en 127.0.0.1; Ctrl+C lo detiene. Para reconstruir el libro: instala `output/source/requirements-book.lock.txt` y ejecuta `python run.py --build`. El build recompila el informe, no repite entrenamientos.

## Procedencia

Fuente documental: `ad8f163c1bbed55348c4af3d3c71b71f57bc7c55`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
