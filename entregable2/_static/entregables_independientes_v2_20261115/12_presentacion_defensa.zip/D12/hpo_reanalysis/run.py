"""Replay the included HPO metadata analysis; no acquisition or fitting."""
from pathlib import Path
import argparse, csv, hashlib, importlib.util, json, shutil, sys
ROOT=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():raise ValueError("Use a fresh HPO-replay output directory")
    config=json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
    program=ROOT/"code/e2_hpo_coverage_closure.py"
    evidence=ROOT.parent/"corrections/hpo"
    if digest(program)!=config["program_sha256"] or digest(evidence/"analysis_plan.json")!=config["plan_sha256"]:raise ValueError("Bound HPO program/plan changed")
    args.output.mkdir(parents=True)
    shutil.copytree(evidence/"sources",args.output/"sources")
    shutil.copyfile(evidence/"analysis_plan.json",args.output/"analysis_plan.json")
    initial=evidence/"analysis_plan_initial_guard_failure.json"
    if initial.is_file():shutil.copyfile(initial,args.output/initial.name)
    spec=importlib.util.spec_from_file_location("e2_hpo_metadata_replay",program)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    summary=module.execute(args.output)
    comparisons=[]
    for name,expected in [("configurations_78.csv",78),("opportunities_234.csv",234),("model_reconciliation_13.csv",13),("parameter_coverage_65.csv",65)]:
        with (args.output/name).open(encoding="utf-8",newline="") as f:rows=list(csv.DictReader(f))
        if len(rows)!=expected:raise ValueError("Replayed HPO table has wrong design count: "+name)
        identical=digest(args.output/name)==digest(evidence/name)
        if not identical:raise ValueError("Replayed HPO table differs from the included reference: "+name)
        comparisons.append({"file":name,"rows":len(rows),"byte_identical_to_included":identical})
    record={"status":"verified","scope":"Registered HPO metadata replay with original source/inputs; no Git, network, new HPO or fitting", "summary":summary,"tables":comparisons}
    (args.output/"portable_replay_report.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(record,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
