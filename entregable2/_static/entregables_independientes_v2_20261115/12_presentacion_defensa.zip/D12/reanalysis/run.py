"""Portable numerical replay of an included immutable correction plan.

The original program bytes and repository-relative inputs are retained. This
adapter calls the registered execute function; it does not register a new plan,
invoke Git, download inputs, train models or rewrite the original evidence.
"""
from pathlib import Path
import argparse, csv, hashlib, importlib.util, json, math, shutil, sys
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    config=json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
    if args.output.exists():raise ValueError("Use a new correction-replay output directory")
    sys.path.insert(0,str(ROOT/"source/scripts"))
    records=[]
    for item in config["programs"]:
        source=ROOT/item["program"]
        if digest(source)!=item["program_sha256"]:raise ValueError("Registered program changed")
        plan=ROOT/item["plan"]
        if digest(plan)!=item["plan_sha256"]:raise ValueError("Registered plan changed")
        destination=args.output/item["id"]
        spec=importlib.util.spec_from_file_location("e2_correction_replay_"+item["id"],source)
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
        if item.get("kind","effects_rq2") in {"inference_statistics","cpu_diagnostic_statistics"}:
            summary=module.execute(argparse.Namespace(plan=plan,predictions_output=ROOT/item["predictions"],latency_output=ROOT/item["latency"],output=destination))
        else:
            destination.mkdir(parents=True)
            shutil.copyfile(plan,destination/"analysis_plan.json")
            summary=module.execute(destination)
        comparisons=[]
        for check in item["comparison_CSVs"]:
            with (ROOT/check["reference"]).open(encoding="utf-8",newline="") as f:expected=list(csv.DictReader(f))
            with (destination/check["name"]).open(encoding="utf-8",newline="") as f:actual=list(csv.DictReader(f))
            if len(expected)!=len(actual):raise ValueError("Replay CSV row count differs: "+check["name"])
            maxdiff=0.0
            for left,right in zip(expected,actual):
                if set(left)!=set(right):raise ValueError("Replay CSV columns differ")
                for key,value in left.items():
                    if value==right[key]:continue
                    try:a,b=float(value),float(right[key])
                    except ValueError:raise ValueError("Replay categorical value differs: "+key)
                    if not (math.isfinite(a) and math.isfinite(b)) or not math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12):raise ValueError("Replay numerical value differs: "+key)
                    maxdiff=max(maxdiff,abs(a-b))
            comparisons.append({"file":check["name"],"rows":len(actual),"maximum_absolute_difference":maxdiff})
        records.append({"program":item["id"],"original_program_bytes_unchanged":True,"summary":summary,"comparisons":comparisons})
    report={"status":"verified","scope":"Numerical replay of included posthoc correction plans; no new registration or model fitting", "source_commit":config["source_commit"],"records":records}
    (args.output/"replay_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
