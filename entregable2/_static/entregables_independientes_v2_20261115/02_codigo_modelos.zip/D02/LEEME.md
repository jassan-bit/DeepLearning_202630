# D02 · Código y ejecución de las trece redes

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

Antes del primer forward, crea un venv e instala sus dependencias: `python -m venv .venv`, activa el entorno y ejecuta `python -m pip install -r requirements_cpu.txt`. Con ese entorno activado, usa `python run.py` también en Windows. Los lanzadores detectan una .venv local. La instalación necesita Internet; después, el inventario y los forwards usan sólo archivos locales. Sin instalar librerías, `python run.py --inventory` verifica las recetas y fuentes. No mezcles el lock CPU y CUDA.

## Qué produce

Verifica fuentes y ejecuta forwards CPU de las 13 redes con entradas artificiales. Es comprobación de implementación, no evaluación con pesos entrenados.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

`python run.py --smoke-cpu` usa pesos iniciales y un fixture [1,7,5]; no afirma precisión Bitcoin. Incluye código original de EDA, modelos, baselines, entrenamiento, estadísticas, robustez, incertidumbre, explicaciones y tests bajo code/. Para un reentrenamiento real opcional, usa Linux/WSL2 y CUDA: instala requirements_cuda.txt en otro venv y ejecuta `python run.py --train --model MLP16 --seed 271801 --device cuda:0 --output nuevo_ajuste`. Emplea 655 ejemplos train, 53 held-out y las épocas congeladas; no abre el controlador ni el presupuesto de la campaña. Esa opción no se ejecutó al preparar el ZIP. No incluye checkpoints originales ni el tensor X de prueba; los resultados del benchmark se reconstruyen sin ellos en D06.

## Procedencia

Fuente documental: `ad8f163c1bbed55348c4af3d3c71b71f57bc7c55`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
