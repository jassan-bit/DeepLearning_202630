# D03 · Datos, Data Card y contrato

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Reconstruye σ7 desde los cierres incluidos y comprueba calidad/calendarios/cohortes. V3 añade evaluación 608 y el NPZ real de 655/53/608; produce informes y CSV sin dependencias científicas.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Incluye los dos CSV diarios de desarrollo, la Data Card, contrato y manifiestos. V3 añade el CSV diario original de evaluación 608 y el NPZ real train655/cal53/test608. CSV diario y tensor causal D7×5 son objetos distintos. El runner reconstruye σ7 y valida los arrays con Python estándar; no ajusta modelos ni calcula scores predictivos. Descarga opcional: `python run.py --download --archive BTCUSDT-1m-2023-01.zip`; requiere Internet y verifica CHECKSUM/hash oficiales. Sin --archive, la descarga selecciona los 24 meses de desarrollo; no se inicia por defecto.

Para obtener las veinte fuentes originales del test conocido de enero de 2025 a agosto de 2026: `python code/scripts/download_e2_known_market.py --output datos_test`. Sólo necesita Python estándar y una red que permita data.binance.vision. Verifica el manifiesto histórico, tamaños y SHA-256; no cambia datos ni inicia ajustes. Para verificar una descarga ya completa: añade `--validate-only`. La descarga no reconstruye por sí sola todos los tensores del benchmark ni declara cerrada una auditoría cuyo test siga sin estar disponible.

## Procedencia

Fuente documental: `78271c46a1fe7a9544e8d1ec46e096dafb7cf9e9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
