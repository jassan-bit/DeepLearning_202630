"""Replay included current statistical results; no fit or inference.

The numerical program and registered plan retain their original bytes. For the
CPU supplement, absolute source identities are mapped to verified local copies;
only that source-location resolver is replaced. No statistical function changes.
"""
from pathlib import Path
import argparse,csv,hashlib,importlib.util,json,math,shutil,sys
BASE=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def checked(name):
    p=(BASE/name).resolve()
    if not p.is_relative_to(BASE.resolve()) or not p.is_file() or p.is_symlink():raise ValueError("Unsafe or missing replay input: "+name)
    return p
def compare(expected,actual):
    with expected.open(newline="",encoding="utf-8") as f:left=list(csv.DictReader(f))
    with actual.open(newline="",encoding="utf-8") as f:right=list(csv.DictReader(f))
    if len(left)!=len(right):raise ValueError("Replayed row count differs")
    maximum=0.0
    for a,b in zip(left,right):
        if set(a)!=set(b):raise ValueError("Replayed columns differ")
        for key,value in a.items():
            if value==b[key]:continue
            try:x,y=float(value),float(b[key])
            except ValueError:raise ValueError("Replayed categorical value differs: "+key)
            if not(math.isfinite(x) and math.isfinite(y) and math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-12)):raise ValueError("Replayed numeric value differs: "+key)
            maximum=max(maximum,abs(x-y))
    return {"rows":len(left),"maximum_absolute_difference":maximum}
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--program",required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    config=json.loads((BASE/"config.json").read_text())
    choices=[r for r in config["programs"] if r["id"]==args.program]
    if len(choices)!=1:raise ValueError("Choose an included program: "+", ".join(r["id"] for r in config["programs"]))
    item=choices[0]
    if args.output.exists():raise ValueError("Use a new replay output directory")
    for record in item["bound_files"]:
        p=checked(record["local_path"])
        if p.stat().st_size!=record["bytes"] or digest(p)!=record["sha256"]:raise ValueError("Replay input checksum changed: "+record["local_path"])
    program=checked(item["program"]);plan=checked(item["plan"])
    if digest(program)!=item["program_sha256"] or digest(plan)!=item["plan_sha256"]:raise ValueError("Registered program or plan changed")
    sys.path.insert(0,str(BASE/"source/scripts"))
    spec=importlib.util.spec_from_file_location("_e2_current_replay_"+item["id"],program)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    args.output.mkdir(parents=True)
    shutil.copyfile(plan,args.output/"analysis_plan.json")
    if item["kind"]=="cpu_statistics":
        archived=json.loads(plan.read_text())
        module.sources=lambda:archived["sources"]
        shutil.copytree(checked(item["inference_report"]).parent,args.output/"inference")
        summary=module.stats_run(args.output,item["plan_sha256"])
        resultdir=args.output/"statistics"
    else:
        summary=module.execute(args.output);resultdir=args.output
    comparisons=[]
    for row in item["comparisons"]:
        comparisons.append({"file":row["name"],**compare(checked(row["reference"]),resultdir/row["name"])})
    record={"status":"verified","source_commit":config["source_commit"],"program":item["id"],"registered_plan_sha256":item["plan_sha256"],"original_program_and_plan_bytes_unchanged":True,"source_relocation":item["source_relocation"],"summary":summary,"comparisons":comparisons,"new_model_fits":0,"new_model_inference":False,"scope":"Numerical reproduction of the included posterior statistical plan; no new registration, originalA2 replacement or originalGPU parity claim"}
    (args.output/"portable_replay_report.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(record,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
