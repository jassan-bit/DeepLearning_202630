# D08 · Techo, incertidumbre y errores

Este ZIP es independiente. Descomprímelo completo en una carpeta nueva. No necesitas clonar el repositorio, acceder al sitio del curso ni descargar otro entregable.

## Ejecutar

Se recomienda Python 3.12. Windows: `py -3.12 run.py`. Linux/macOS: `python3 run.py`. También se incluyen `ejecutar.cmd` y `ejecutar.sh`.

## Qué produce

Reconstruye métricas/cobertura originales y 6.080 categorías de error; compara con los resultados guardados. Incluye las políticas e IC publicados.

Las salidas se escriben dentro del paquete; no modifican los datos científicos incluidos. D03 usa `output/dataset_audit.html`; los otros informes usan `output/informe.html`, y D01 ofrece el sitio completo en `output/site/intro.html`.

## Alcance y opciones

Default: biblioteca estándar y datos incluidos. Reproducir frecuencias/cobertura no demuestra cobertura universal ni un techo Bayes. Para ejecutar los programas estadísticos completos originales, instala requirements_analysis.txt y ejecuta `python run.py --full-uncertainty --output reanalisis_completo`. Son remuestreos CPU y pueden tardar; se conservan planes/semillas y no se ajustan nuevos pesos de ensemble.

## Procedencia

Fuente documental: `78271c46a1fe7a9544e8d1ec46e096dafb7cf9e9`. Los archivos originales conservan sus bytes y los programas nuevos son adaptadores de entrega. `source_manifest.json` enumera rutas, tamaños y SHA-256 de los archivos del paquete; `package.json` describe el componente. Los resultados locales no se confunden con otra campaña científica. No se incluyen credenciales, .git, Colab o rutas privadas necesarias para ejecutar. Las licencias de autores y datasets incluidos se conservan junto a sus fuentes.
