# Entregable 1: siete productos

Descomprimir este paquete y después cada ZIP según el ítem. Cada producto tiene LEEME.md y MANIFIESTO.json con hashes.


Se conserva el alcance científico del libro: Miura2019 respalda MLP/CNN independientes como familias; no declara dimensionalidad CNN ni demuestra una réplica exacta o uso amplio. suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
