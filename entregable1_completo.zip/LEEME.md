# Entregable 1: siete productos

Descomprimir este paquete y después cada ZIP según el ítem. Cada producto tiene LEEME.md y MANIFIESTO.json con hashes.


Se conserva el alcance científico del libro: seis textos del corpus BTC y39 referencias. Miura2019 respalda MLP/CNN independientes como familias. Bucci2020 aporta un original de revista con FNN financiera; HARNet aporta código autor Conv1D; DeepVol tiene identidad editorial en CV, con original pendiente. Estas fuentes metodológicas no añaden estudios BTC ni revelan la dimensionalidad no reportada de la CNN de Miura. No son réplicas de las recetas. Se conservan el suplemento final post-hoc y el piloto histórico registrado de60 trayectorias. El estudio D7 registrado se entrega por separado: ampliación de20 semillas por modelo y definitiva de79 semillas nuevas por modelo, con R publicado antes de esa fase. Ambas fases se condicionan al calendario2024 conocido y no reabren el test histórico. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
