# 8.4. Síntesis de literatura y flujo

Fuente versionada: dbacc1db55b2c802782a9cc01968026e5a6b2cdb.

La síntesis vigente de seis estudios, frecuencias y Tabla1 de Miura2019 están en book/_static/literature_e1/recovery_20261105/. La bibliografía principal reúne36referencias. Los archivos anteriores conservan sus cortes históricos; no sumar etapas sin deduplicación. No se incluyen manuscritos de terceros.

Se conserva el alcance científico del libro: Miura2019 respalda MLP/CNN independientes como familias; no declara dimensionalidad CNN ni demuestra una réplica exacta o uso amplio. suplemento final post-hoc y nuevo piloto registrado de60 trayectorias; el R definitivo aún no se ejecutó. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
