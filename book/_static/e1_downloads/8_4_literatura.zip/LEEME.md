# 8.4. Literatura y selección de GRU–LSTM–TCN

Fuente de esta actualización: `29a18878cc27d08db88033d5f2fd5df5b6d52a42`.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. La auditoría forense y la repetibilidad actual tienen alcance separado de la identidad histórica; las búsquedas nuevas conservan su propia procedencia. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística, curvas, auditoría forense y repetibilidad actual con alcances identificados; 8.6 conserva sus configuraciones originales y añade los protocolos y metadatos correspondientes. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.4. Literatura y selección de GRU–LSTM–TCN

Fuente de esta actualización: `09a108efc7f0fdd17137fbc3f61f08b331b4a30b`.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.4. Literatura y selección de GRU–LSTM–TCN

Fuente de esta actualización: `8566b157c9fd765c85915971af13fb9d01e4aa88`.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.4. Literatura y selección de GRU–LSTM–TCN

Fuente de esta actualización: `3b5fd5935709824c1451a829bf30b443017f11b4`.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.4. Literatura y selección de GRU–LSTM–TCN

Fuente de esta actualización: `006c997926a467f024b2c863eddc51c17c4f2d0c`.

La ampliación bibliográfica, la comparación documental y el suplemento estadístico del 6 de noviembre de 2026 son posteriores a los experimentos documentados. Esta ampliación no constituye un prerregistro retrospectivo, no modifica sus configuraciones, resultados ni cronologías y no añade ajustes o pronósticos. Los nuevos contrastes son análisis suplementarios posteriores; los estratos históricos de literatura conservan su identidad.

Los productos 8.3 y 8.6 conservan exactamente los ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística suplementaria posterior; 8.7 incorpora la comparación documental. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.4. Literatura y selección de GRU–LSTM–TCN

La selección vigente está en `book/_static/literature_e1/gru_lstm_tcn_selection_20261105/`. Se incluyen síntesis, flujo y registros bibliográficos. Las menciones a otros modelos en artículos o cortes históricos no los convierten en modelos experimentales actuales. No se redistribuyen manuscritos.

Terna experimental: **GRU–LSTM–TCN**. El primer benchmark tiene como baseline neuronal **GRU/D7**, seleccionado en CV antes de esa evaluación del test histórico ya conocido. Fuente versionada: `ff3631f0711dad55522b1dff618f468e9849d8a2`.

En ese primer benchmark, las comparaciones entre los tres modelos y los diagnósticos adicionales se definieron después de observar el test: su alcance es exploratorio. Sus diez semillas son un presupuesto fijo; no se atribuye a esa fase un piloto prospectivo ni potencia 0,80. Su margen operativo futuro se declaró después del test y no se aplica retroactivamente. Persistencia conserva su papel de referencia.

Los paquetes públicos contienen código, metadatos, agregados y figuras. Se excluyen archivos crudos, pesos, escaladores y series diarias o vectores individuales legibles por máquina. La ilustración PNG de la **fase I** utiliza la semilla fija 4101; la de la **fase II** utiliza la semilla fija 8101. Ninguna semilla se elige por su error y no se entregan sus CSV individuales. El adaptador público de reproducción de la **fase I** es posterior a su ejecución original y no sustituye sus firmas históricas. El código científico de la fase II tiene su propio registro previo a esa ejecución.

La licencia MIT incluida corresponde a timeseries-cv; no asigna una licencia general al proyecto. Los términos de la fuente de datos se conservan en el producto 8.3.


**Segunda fase D7 planificada:** el paquete también contiene el diseño y código registrados antes de ejecutar HPO, el mismo presupuesto de búsqueda por familia, un piloto separado, dimensionamiento por potencia condicional entre semillas y evaluación preespecificada del 01/09 al 30/10/2026. Sus resultados y cronología están en `book/_static/gru_lstm_tcn_planned_20261105/`. La reserva es histórica: no son pronósticos emitidos en vivo ni una validación en otro mercado. La potencia de planificación entre semillas no acredita potencia temporal del periodo. Las conclusiones del primer benchmark conservan su alcance exploratorio.
