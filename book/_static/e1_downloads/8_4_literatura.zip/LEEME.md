# 8.4. Síntesis de literatura y flujo

Fuente versionada: 99bb25def5d760ab2fe0e719c1d79c59804b8935.

Las tablas CSV, referencias BibTeX y flow.svg están bajo book/_static/literature_e1/. La recuperación complementaria de la auditoría está separada; no sumar sus conteos sin deduplicación. No se incluyen manuscritos de terceros.

Se conserva el alcance científico del libro: respaldo aplicado parcial de MLP/CNN1D; suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
