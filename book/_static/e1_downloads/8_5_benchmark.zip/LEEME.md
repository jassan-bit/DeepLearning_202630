# 8.5. Benchmark e inferencia agregada

Fuente versionada: 67a082e57bafdcd60dde0aa70843449c473a8c56.

Abrir los CSV con un lector compatible con UTF-8. analysis_cv/ contiene desarrollo; test/analysis/ contiene test. Los suplementos inference/ y descriptive/ conservan su registro post-hoc. e1_filipe_pilot_20261105/ contiene el nuevo piloto sobre validación2024 y su dimensionamiento condicional. Los manifiestos verifican los agregados originales.

Se conserva el alcance científico del libro: seis textos del corpus BTC y39 referencias. Miura2019 respalda MLP/CNN independientes como familias. Bucci2020 aporta un original de revista con FNN financiera; HARNet aporta código autor Conv1D; DeepVol tiene identidad editorial en CV, con original pendiente. Estas fuentes metodológicas no añaden estudios BTC ni revelan la dimensionalidad no reportada de la CNN de Miura. No son réplicas de las recetas. suplemento final post-hoc y nuevo piloto registrado de60 trayectorias; el R definitivo aún no se ejecutó. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
