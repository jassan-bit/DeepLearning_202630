# 8.3. Instrucciones y adquisición del dataset

Fuente versionada: aaeee5d8568b4828301148efe86712585fbe93e4.

Leer data/README.md. El script scripts/download_binance_spot.py obtiene los archivos oficiales y verifica checksums. Los manifiestos identifican fuente, fechas, bytes y SHA-256. Este paquete no contiene datos brutos de Binance.

Se conserva el alcance científico del libro: Miura2019 respalda MLP/CNN independientes como familias; no declara dimensionalidad CNN ni demuestra una réplica exacta o uso amplio. suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
