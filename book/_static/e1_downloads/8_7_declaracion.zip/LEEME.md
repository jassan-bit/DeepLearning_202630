# 8.7. Declaración y cronología vigentes

Leer la declaración y cronología de `gru_lstm_tcn_delivery_20261105/`, junto con `selected_by_cv.json`, `protocols_manifest.json`, `public_analysis_plan.json` y `future_margin.json`. Distinguen selección previa en CV, evaluación de un test ya observado, análisis posteriores y requisitos futuros.

Terna experimental vigente: **GRU–LSTM–TCN**. Baseline neural: **GRU/D7**, seleccionado en CV antes de la nueva evaluación del test histórico ya conocido. Fuente versionada: `428d5d07742d87f5ee47fbe9e7ea4738e61a84a3`.

Las comparaciones actuales entre los tres modelos y los diagnósticos adicionales se definieron después de observar el test: su alcance es exploratorio. Las diez semillas son un presupuesto fijo; no se atribuye un piloto prospectivo de los modelos nuevos ni potencia 0,80. El margen operativo futuro se declara después del test y no se aplica retroactivamente. Persistencia conserva su papel de referencia.

Los paquetes públicos contienen código, metadatos, agregados y figuras. Se excluyen archivos crudos, pesos, escaladores y series diarias o vectores individuales legibles por máquina. Se incluye una ilustración PNG de observado frente a predicho con la semilla4101 fija, sin su CSV individual y sin seleccionar la semilla por su error. El adaptador público de reproducción es posterior a la ejecución original y no sustituye sus firmas históricas.

La licencia MIT incluida corresponde a timeseries-cv; no asigna una licencia general al proyecto. Los términos de la fuente de datos se conservan en el producto 8.3.
