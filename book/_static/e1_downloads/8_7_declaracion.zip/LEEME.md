# 8.7. Declaración y cronología vigentes

Fuente de esta actualización: `006c997926a467f024b2c863eddc51c17c4f2d0c`.

La ampliación bibliográfica, la comparación documental y el suplemento estadístico del 6 de noviembre de 2026 son posteriores a los experimentos documentados. Esta ampliación no constituye un prerregistro retrospectivo, no modifica sus configuraciones, resultados ni cronologías y no añade ajustes o pronósticos. Los nuevos contrastes son análisis suplementarios posteriores; los estratos históricos de literatura conservan su identidad.

Los productos 8.3 y 8.6 conservan exactamente los ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística suplementaria posterior; 8.7 incorpora la comparación documental. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.7. Declaración y cronología vigentes

La declaración histórica de la **fase I** está en `gru_lstm_tcn_delivery_20261105/`, con sus análisis y margen posteriores al test. La **fase II** conserva `design.json`, `public_preregistration.json`, `closed_planning.json`, `public_dimensioning.json`, `dimensioning.json` y `chronology.json` en `gru_lstm_tcn_planned_20261105/`: identifican registro público, recetas y R cerrados antes del ajuste definitivo, y pesos cerrados antes del acceso a la reserva histórica adicional. Ninguna fase acredita potencia temporal o predicción en vivo.

Terna experimental: **GRU–LSTM–TCN**. El primer benchmark tiene como baseline neuronal **GRU/D7**, seleccionado en CV antes de esa evaluación del test histórico ya conocido. Fuente versionada: `ff3631f0711dad55522b1dff618f468e9849d8a2`.

En ese primer benchmark, las comparaciones entre los tres modelos y los diagnósticos adicionales se definieron después de observar el test: su alcance es exploratorio. Sus diez semillas son un presupuesto fijo; no se atribuye a esa fase un piloto prospectivo ni potencia 0,80. Su margen operativo futuro se declaró después del test y no se aplica retroactivamente. Persistencia conserva su papel de referencia.

Los paquetes públicos contienen código, metadatos, agregados y figuras. Se excluyen archivos crudos, pesos, escaladores y series diarias o vectores individuales legibles por máquina. La ilustración PNG de la **fase I** utiliza la semilla fija 4101; la de la **fase II** utiliza la semilla fija 8101. Ninguna semilla se elige por su error y no se entregan sus CSV individuales. El adaptador público de reproducción de la **fase I** es posterior a su ejecución original y no sustituye sus firmas históricas. El código científico de la fase II tiene su propio registro previo a esa ejecución.

La licencia MIT incluida corresponde a timeseries-cv; no asigna una licencia general al proyecto. Los términos de la fuente de datos se conservan en el producto 8.3.


**Segunda fase D7 planificada:** el paquete también contiene el diseño y código registrados antes de ejecutar HPO, el mismo presupuesto de búsqueda por familia, un piloto separado, dimensionamiento por potencia condicional entre semillas y evaluación preespecificada del 01/09 al 30/10/2026. Sus resultados y cronología están en `book/_static/gru_lstm_tcn_planned_20261105/`. La reserva es histórica: no son pronósticos emitidos en vivo ni una validación en otro mercado. La potencia de planificación entre semillas no acredita potencia temporal del periodo. Las conclusiones del primer benchmark conservan su alcance exploratorio.
