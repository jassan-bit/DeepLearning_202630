# Evidencias y análisis posteriores del 6 de noviembre de 2026

La ampliación bibliográfica, la comparación documental y el suplemento estadístico del 6 de noviembre de 2026 son posteriores a los experimentos documentados. Esta ampliación no constituye un prerregistro retrospectivo, no modifica sus configuraciones, resultados ni cronologías y no añade ajustes o pronósticos. Los nuevos contrastes son análisis suplementarios posteriores; los estratos históricos de literatura conservan su identidad.

8.7 añade la comparación documental y sensibilidad del margen; 8.4 incluye el cribado editorial y la síntesis de selección; 8.5 añade Q–Q, contraste global y sensibilidad no paramétrica calculados desde métricas guardadas. Aquí se conservan resúmenes y manifiestos. Los resultados y fuentes prerregistrados no se reescriben; los vectores diarios, pesos y escaladores permanecen fuera de la entrega pública.
