# Ampliación literaria del 6 de noviembre de 2026

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.4 contiene los metadatos públicos completos de las nuevas etapas; aquí se conservan sus resúmenes, manifiestos y procedencia. No se redistribuyen los archivos de búsqueda originales, resúmenes editoriales ni PDF de terceros.
