# 8.1. Informe HTML vigente

Fuente de esta actualización: `8566b157c9fd765c85915971af13fb9d01e4aa88`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

Fuente de esta actualización: `3b5fd5935709824c1451a829bf30b443017f11b4`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

La portada y las tablas presentan la evaluación D7 como modelo final. Abrir `informe/intro.html` después de descomprimir. Las métricas, selección del baseline y cronologías se conservan.

Fuente de presentación: `6ab6e55fe02bd217bcd97c3ecf0cca679ecb3bdd`.
