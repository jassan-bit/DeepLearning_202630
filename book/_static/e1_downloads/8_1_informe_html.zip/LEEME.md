# 8.1. Informe HTML vigente

La portada y las tablas presentan la evaluación D7 como modelo final. Abrir `informe/intro.html` después de descomprimir. Las métricas, selección del baseline y cronologías se conservan.

Fuente de presentación: `6ab6e55fe02bd217bcd97c3ecf0cca679ecb3bdd`.
