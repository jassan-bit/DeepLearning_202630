# 8.1. Informe HTML vigente

Fuente de esta actualización: `60836db5cf9cdefb838a35ec103650444e70cbb7`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. La auditoría forense y la repetibilidad actual tienen alcance separado de la identidad histórica; las búsquedas nuevas conservan su propia procedencia. La búsqueda web dirigida de trece obras y su conciliación acumulada conservan los ámbitos, papeles y niveles de lectura; no convierten la cuota de selección por arquitectura en frecuencia del corpus. La selección del núcleo LSTM–MLP–GRU y su nueva ejecución conservan como exploratoria la evaluación de septiembre–octubre de 2026 ya observada; los resultados anteriores de TCN permanecen complementarios y separados. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade el núcleo histórico compatible y la nueva ejecución común LSTM–MLP–GRU, además de estadística, curvas, auditoría forense y repetibilidad actual con alcances identificados; 8.6 conserva sus configuraciones originales y añade los protocolos y metadatos correspondientes. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

Fuente de esta actualización: `a3924e169aef25d293b1cef9cef39a6c07ddd433`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. La auditoría forense y la repetibilidad actual tienen alcance separado de la identidad histórica; las búsquedas nuevas conservan su propia procedencia. La búsqueda web dirigida de trece obras y su conciliación acumulada conservan los ámbitos, papeles y niveles de lectura; no convierten la cuota de selección por arquitectura en frecuencia del corpus. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística, curvas, auditoría forense y repetibilidad actual con alcances identificados; 8.6 conserva sus configuraciones originales y añade los protocolos y metadatos correspondientes. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

Fuente de esta actualización: `29a18878cc27d08db88033d5f2fd5df5b6d52a42`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. La auditoría forense y la repetibilidad actual tienen alcance separado de la identidad histórica; las búsquedas nuevas conservan su propia procedencia. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística, curvas, auditoría forense y repetibilidad actual con alcances identificados; 8.6 conserva sus configuraciones originales y añade los protocolos y metadatos correspondientes. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

Fuente de esta actualización: `09a108efc7f0fdd17137fbc3f61f08b331b4a30b`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

Fuente de esta actualización: `8566b157c9fd765c85915971af13fb9d01e4aa88`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

Fuente de esta actualización: `3b5fd5935709824c1451a829bf30b443017f11b4`.

Abrir `informe/intro.html` después de descomprimir. Los enlaces a descargas históricas excluidas se dirigen al libro público; no se incluyen ZIP recursivos.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.

El producto 8.3 conserva exactamente el ZIP de la entrega base. 8.5 conserva sus archivos científicos originales y añade estadística y curvas de una reproducción identificada; 8.6 conserva sus configuraciones originales y añade el protocolo y metadatos de esa reproducción. 8.7 incorpora contexto documental, margen y procedencia. Los manifiestos internos identifican los bytes realmente incluidos.

## Notas conservadas de la entrega base

# 8.1. Informe HTML vigente

La portada y las tablas presentan la evaluación D7 como modelo final. Abrir `informe/intro.html` después de descomprimir. Las métricas, selección del baseline y cronologías se conservan.

Fuente de presentación: `6ab6e55fe02bd217bcd97c3ecf0cca679ecb3bdd`.
