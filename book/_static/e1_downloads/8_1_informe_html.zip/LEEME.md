# 8.1. Informe HTML vigente

Descomprimir y abrir `informe/intro.html`. Alternativa: `python -m http.server 8000 --directory informe`. Los ZIP y otros artefactos excluidos de este informe mantienen enlaces a su ruta pública online; se evita la recursión de descargas. MathJax puede necesitar conexión.

Terna experimental vigente: **GRU–LSTM–TCN**. Baseline neural: **GRU/D7**, seleccionado en CV antes de la nueva evaluación del test histórico ya conocido. Fuente versionada: `7739deb9765eca7861f996b6252ad70cad3f7e23`.

Las comparaciones actuales entre los tres modelos y los diagnósticos adicionales se definieron después de observar el test: su alcance es exploratorio. Las diez semillas son un presupuesto fijo; no se atribuye un piloto prospectivo de los modelos nuevos ni potencia 0,80. El margen operativo futuro se declara después del test y no se aplica retroactivamente. Persistencia conserva su papel de referencia.

Los paquetes públicos contienen código, metadatos, agregados y figuras. Se excluyen archivos crudos, pesos, escaladores y series diarias o vectores individuales legibles por máquina. Se incluye una ilustración PNG de observado frente a predicho con la semilla4101 fija, sin su CSV individual y sin seleccionar la semilla por su error. El adaptador público de reproducción es posterior a la ejecución original y no sustituye sus firmas históricas.

La licencia MIT incluida corresponde a timeseries-cv; no asigna una licencia general al proyecto. Los términos de la fuente de datos se conservan en el producto 8.3.
