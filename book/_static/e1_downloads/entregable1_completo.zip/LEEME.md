# Entregable 1 completo

Descomprimir este ZIP y cada producto. El informe presenta el modelo final D7; los seis productos restantes conservan exactamente sus archivos y procedencia anteriores.
