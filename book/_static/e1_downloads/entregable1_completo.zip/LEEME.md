# Entregable 1: siete productos vigentes

Descomprimir este ZIP y después cada producto. Cada producto conserva su LEEME.md y MANIFIESTO.json.

La recuperación bibliográfica y la fundamentación académica del margen son posteriores a los experimentos iniciales. La reproducción de curvas tiene un protocolo y registro propios y realiza nuevos ajustes de desarrollo; no sustituye los originales históricos ni modifica sus resultados, recetas, selección o cronologías. Los contrastes suplementarios anteriores conservan su carácter posterior. Esta actualización no constituye un prerregistro retrospectivo. Empaquetar consume las evidencias guardadas y no ejecuta ajustes o pronósticos.
