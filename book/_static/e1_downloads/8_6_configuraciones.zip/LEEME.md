# 8.6. Dependencias, semillas y configuraciones

Fuente versionada: 99bb25def5d760ab2fe0e719c1d79c59804b8935.

Los locks y los catálogos identifican 1.440 segmentos modelo-mes de CV y 120 ajustes finales. Las filas son metadatos, sin pesos ni valores de escaladores. No mezclar el entorno CV con el de entrenamiento.

Se conserva el alcance científico del libro: respaldo aplicado parcial de MLP/CNN1D; suplemento final post-hoc y piloto futuro sin ejecutar. La política académica futura no se presenta como anterior al test. Pesos, escaladores y predicciones individuales requieren la entrega privada descrita en BUILD.md; este ZIP no los contiene.
No se asigna una licencia general al proyecto. El aviso MIT de timeseries-cv se refiere a ese proyecto; los términos de Binance se consultan en el paquete del dataset.
